<?php
session_start();
require_once "../model/dao/AbonneDAO.php";

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: ../login.php");
    exit;
}

$message = "";

if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'supprimer') {
    $id = (int)$_GET['id'];
    if ($id > 0) {
        AbonneDAO::delete($id);
        $message = "Abonné supprimé.";
    }
}

// Recherche
$recherche = trim($_GET['q'] ?? '');
$abonnes   = AbonneDAO::getAll();

if ($recherche !== '') {
    $abonnes = array_filter($abonnes, function($a) use ($recherche) {
        $hay = strtolower($a->getNom() . ' ' . $a->getPrenom() . ' ' . $a->getEmail());
        return str_contains($hay, strtolower($recherche));
    });
}

include '_nav.php';
?>

<h1>Gestion des abonnés</h1>

<?php if ($message): ?>
    <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<!-- Barre de recherche -->
<div class="card" style="padding:12px 16px;">
    <form method="GET" style="display:flex;gap:10px;align-items:center;">
        <input type="text" name="q" value="<?= htmlspecialchars($recherche) ?>"
               placeholder="Rechercher par nom, prénom, email…"
               style="flex:1;padding:7px 10px;border:1px solid #ccc;border-radius:4px;">
        <button type="submit" class="btn btn-primary">Rechercher</button>
        <?php if ($recherche): ?>
            <a href="adminGestionAbonnes.php" class="btn btn-warning">Réinitialiser</a>
        <?php endif; ?>
    </form>
</div>

<div class="card">
    <?php if (empty($abonnes)): ?>
        <p>Aucun abonné trouvé.</p>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Email</th>
                <th>Téléphone</th>
                <th>Statut</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($abonnes as $abonne): ?>
            <tr>
                <td><?= $abonne->getId() ?></td>
                <td><?= htmlspecialchars($abonne->getNom()) ?></td>
                <td><?= htmlspecialchars($abonne->getPrenom()) ?></td>
                <td><?= htmlspecialchars($abonne->getEmail()) ?></td>
                <td><?= htmlspecialchars($abonne->getTelephone()) ?></td>
                <td>
                    <?php if ($abonne->getStatut() === 'valide'): ?>
                        <span class="badge badge-green">Validé</span>
                    <?php else: ?>
                        <span class="badge badge-orange">En attente</span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="?action=supprimer&id=<?= $abonne->getId() ?>"
                       class="btn btn-danger btn-sm"
                       onclick="return confirm('Supprimer cet abonné définitivement ?')">Supprimer</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include '_footer.php'; ?>
