<?php
session_start();
require_once "../model/dao/AbonneDAO.php";
require_once "../model/dao/MaterielDAO.php";
require_once "../model/dao/EmpruntDAO.php";
require_once "../model/dao/CategorieDAO.php";

// Vérification : admin connecté
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: ../login.php");
    exit;
}

// Statistiques rapides
$abonnes        = AbonneDAO::getAll();
$materiels      = MaterielDAO::getAll();
$emprunts       = EmpruntDAO::getAll();
$categories     = CategorieDAO::getAll();

$nbAbonnes      = count($abonnes);
$nbMateriels    = count($materiels);
$nbEmprunts     = count($emprunts);
$nbCategories   = count($categories);

$nbEnAttente    = count(array_filter($abonnes,  fn($a) => $a->getStatut() === 'en_attente'));
$nbEnCours      = count(array_filter($emprunts, fn($e) => $e->getStatut() === 'en_cours'));
$nbDispo        = count(array_filter($materiels, fn($m) => $m->isDisponible()));

include '_nav.php';
?>

<h1>Tableau de bord</h1>

<div class="stats-grid">
    <div class="stat">
        <div class="number"><?= $nbAbonnes ?></div>
        <div class="label">Abonnés</div>
    </div>
    <div class="stat">
        <div class="number"><?= $nbEnAttente ?></div>
        <div class="label">Comptes en attente</div>
    </div>
    <div class="stat">
        <div class="number"><?= $nbMateriels ?></div>
        <div class="label">Matériels</div>
    </div>
    <div class="stat">
        <div class="number"><?= $nbDispo ?></div>
        <div class="label">Disponibles</div>
    </div>
    <div class="stat">
        <div class="number"><?= $nbEmprunts ?></div>
        <div class="label">Emprunts totaux</div>
    </div>
    <div class="stat">
        <div class="number"><?= $nbEnCours ?></div>
        <div class="label">Emprunts en cours</div>
    </div>
    <div class="stat">
        <div class="number"><?= $nbCategories ?></div>
        <div class="label">Catégories</div>
    </div>
</div>

<?php if ($nbEnAttente > 0): ?>
<div class="alert alert-info">
    <?= $nbEnAttente ?> compte(s) en attente de validation.
    <a href="adminValidationComptes.php">Valider maintenant →</a>
</div>
<?php endif; ?>

<div class="card">
    <h2 style="margin-bottom:12px;">Accès rapides</h2>
    <div style="display:flex;gap:10px;flex-wrap:wrap;">
        <a href="adminValidationComptes.php" class="btn btn-primary">Valider des comptes</a>
        <a href="adminGestionAbonnes.php"    class="btn btn-primary">Gérer les abonnés</a>
        <a href="adminGestionMateriel.php"   class="btn btn-primary">Gérer les matériels</a>
        <a href="adminGestionEmprunts.php"   class="btn btn-primary">Voir les emprunts</a>
        <a href="adminAjouterCategorie.php"  class="btn btn-primary">Ajouter une catégorie</a>
    </div>
</div>

<?php include '_footer.php'; ?>
