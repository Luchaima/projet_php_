<?php // admin/_footer.php ?>
</main>
<footer>
    &copy; <?= date('Y') ?> ECO'LOC — Panneau d'administration
</footer>
</body>
</html>
