<?php
session_start();
require_once "../model/dao/EmpruntDAO.php";
require_once "../model/dao/MaterielDAO.php";
require_once "../model/dao/AbonneDAO.php";

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: ../login.php");
    exit;
}

$message = "";


if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'cloturer') {
    $id = (int)$_GET['id'];
    if ($id > 0) {
        EmpruntDAO::cloturerEmprunt($id);
        $message = "Emprunt clôturé.";
    }
}


$emprunts  = EmpruntDAO::getAll();
$materiels = MaterielDAO::getAll();
$abonnes   = AbonneDAO::getAll();


$matMap = [];
foreach ($materiels as $m) { $matMap[$m->getId()] = $m; }
$aboMap = [];
foreach ($abonnes  as $a) { $aboMap[$a->getId()] = $a; }

// Filtre statut
$filtreStatut = $_GET['statut'] ?? '';
if ($filtreStatut !== '') {
    $emprunts = array_filter($emprunts, fn($e) => $e->getStatut() === $filtreStatut);
}

// Tri : plus récents d'abord
usort($emprunts, fn($a, $b) => strcmp($b->getDateDebut(), $a->getDateDebut()));

$statutLabels = [
    'en_attente' => ['label' => 'En attente',  'badge' => 'badge-orange'],
    'en_cours'   => ['label' => 'En cours',    'badge' => 'badge-green'],
    'termine'    => ['label' => 'Terminé',     'badge' => 'badge-grey'],
    'refuse'     => ['label' => 'Refusé',      'badge' => 'badge-red'],
];

include '_nav.php';
?>

<h1>Gestion des emprunts</h1>

<?php if ($message): ?>
    <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<!-- Filtre statut -->
<div class="card" style="padding:12px 16px;">
    <form method="GET" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
        <label style="font-weight:bold;margin:0;">Filtrer :</label>
        <?php
        $filtres = ['' => 'Tous', 'en_attente' => 'En attente', 'en_cours' => 'En cours', 'termine' => 'Terminés', 'refuse' => 'Refusés'];
        foreach ($filtres as $val => $lib):
        ?>
            <a href="?statut=<?= $val ?>"
               class="btn btn-sm <?= $filtreStatut === $val ? 'btn-primary' : 'btn-warning' ?>">
                <?= $lib ?>
            </a>
        <?php endforeach; ?>
    </form>
</div>

<div class="card">
    <?php if (empty($emprunts)): ?>
        <p>Aucun emprunt trouvé.</p>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Matériel</th>
                <th>Emprunteur</th>
                <th>Date début</th>
                <th>Date fin</th>
                <th>Statut</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($emprunts as $e):
            $mat = $matMap[$e->getIdMateriel()]   ?? null;
            $abo = $aboMap[$e->getIdEmprunteur()] ?? null;
            $st  = $statutLabels[$e->getStatut()] ?? ['label' => $e->getStatut(), 'badge' => 'badge-grey'];
        ?>
            <tr>
                <td><?= $e->getId() ?></td>
                <td><?= htmlspecialchars($mat ? $mat->getNom() : '—') ?></td>
                <td><?= htmlspecialchars($abo ? $abo->getNom() . ' ' . $abo->getPrenom() : '—') ?></td>
                <td><?= htmlspecialchars($e->getDateDebut()) ?></td>
                <td><?= htmlspecialchars($e->getDateFin() ?? '—') ?></td>
                <td><span class="badge <?= $st['badge'] ?>"><?= $st['label'] ?></span></td>
                <td>
                    <?php if ($e->getStatut() === 'en_cours'): ?>
                        <a href="?action=cloturer&id=<?= $e->getId() ?>&statut=<?= $filtreStatut ?>"
                           class="btn btn-warning btn-sm"
                           onclick="return confirm('Clôturer cet emprunt ?')">Clôturer</a>
                    <?php else: ?>
                        <span style="color:#aaa;font-size:0.8em;">—</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include '_footer.php'; ?>
