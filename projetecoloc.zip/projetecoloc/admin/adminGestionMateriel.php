<?php
session_start();
require_once "../model/dao/MaterielDAO.php";
require_once "../model/dao/CategorieDAO.php";
require_once "../model/dao/AbonneDAO.php";

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: ../login.php");
    exit;
}

$message = "";

// Suppression
if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'supprimer') {
    $id = (int)$_GET['id'];
    if ($id > 0) {
        MaterielDAO::delete($id);
        $message = "Matériel supprimé.";
    }
}


$materiels  = MaterielDAO::getAll();
$categories = CategorieDAO::getAll();
$catMap     = [];
foreach ($categories as $c) {
    $catMap[$c->getId()] = $c->getLibelle();
}

// Filtre par catégorie
$filtreCategorie = (int)($_GET['categorie'] ?? 0);
if ($filtreCategorie > 0) {
    $materiels = array_filter($materiels, fn($m) => $m->getIdCategorie() === $filtreCategorie);
}

include '_nav.php';
?>

<h1>Gestion des matériels</h1>

<?php if ($message): ?>
    <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<div class="card" style="padding:12px 16px;">
    <form method="GET" style="display:flex;gap:10px;align-items:center;">
        <label style="font-weight:bold;margin:0;">Filtrer par catégorie :</label>
        <select name="categorie" style="padding:7px 10px;border:1px solid #ccc;border-radius:4px;">
            <option value="0">Toutes</option>
            <?php foreach ($categories as $c): ?>
                <option value="<?= $c->getId() ?>" <?= $filtreCategorie === $c->getId() ? 'selected' : '' ?>>
                    <?= htmlspecialchars($c->getLibelle()) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-primary">Filtrer</button>
        <?php if ($filtreCategorie): ?>
            <a href="adminGestionMateriel.php" class="btn btn-warning">Tout afficher</a>
        <?php endif; ?>
    </form>
</div>

<div class="card">
    <?php if (empty($materiels)): ?>
        <p>Aucun matériel trouvé.</p>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Nom</th>
                <th>Catégorie</th>
                <th>État</th>
                <th>Durée max (j)</th>
                <th>Disponible</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($materiels as $m): ?>
            <tr>
                <td><?= $m->getId() ?></td>
                <td><?= htmlspecialchars($m->getNom()) ?></td>
                <td><?= htmlspecialchars($catMap[$m->getIdCategorie()] ?? '—') ?></td>
                <td><?= htmlspecialchars($m->getEtat()) ?></td>
                <td><?= $m->getDureeMax() ?></td>
                <td>
                    <?php if ($m->isDisponible()): ?>
                        <span class="badge badge-green">Oui</span>
                    <?php else: ?>
                        <span class="badge badge-red">Non</span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="?action=supprimer&id=<?= $m->getId() ?>&categorie=<?= $filtreCategorie ?>"
                       class="btn btn-danger btn-sm"
                       onclick="return confirm('Supprimer ce matériel ?')">Supprimer</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include '_footer.php'; ?>
