<?php
session_start();
require_once "../model/dao/AbonneDAO.php";

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: ../login.php");
    exit;
}

$message = "";

if (isset($_GET['action'], $_GET['id'])) {
    $id     = (int)$_GET['id'];
    $action = $_GET['action'];

    if ($action === 'valider' && $id > 0) {
        AbonneDAO::validerCompte($id);
        $message = "Compte validé avec succès.";
    } elseif ($action === 'refuser' && $id > 0) {
        AbonneDAO::refuserCompte($id);
        $message = "Compte refusé et supprimé.";
    }
}


$enAttente = array_filter(AbonneDAO::getAll(), fn($a) => $a->getStatut() === 'en_attente');

include '_nav.php';
?>

<h1>Validation des comptes</h1>

<?php if ($message): ?>
    <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<?php if (empty($enAttente)): ?>
    <div class="alert alert-info">Aucun compte en attente de validation.</div>
<?php else: ?>
<div class="card">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Email</th>
                <th>Téléphone</th>
                <th>Adresse</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($enAttente as $abonne): ?>
            <tr>
                <td><?= $abonne->getId() ?></td>
                <td><?= htmlspecialchars($abonne->getNom()) ?></td>
                <td><?= htmlspecialchars($abonne->getPrenom()) ?></td>
                <td><?= htmlspecialchars($abonne->getEmail()) ?></td>
                <td><?= htmlspecialchars($abonne->getTelephone()) ?></td>
                <td><?= htmlspecialchars($abonne->getAdresse()) ?></td>
                <td style="white-space:nowrap;">
                    <a href="?action=valider&id=<?= $abonne->getId() ?>"
                       class="btn btn-success btn-sm"
                       onclick="return confirm('Valider ce compte ?')">Valider</a>
                    <a href="?action=refuser&id=<?= $abonne->getId() ?>"
                       class="btn btn-danger btn-sm"
                       onclick="return confirm('Refuser et supprimer ce compte ?')">Refuser</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php include '_footer.php'; ?>
