<?php
// admin/_nav.php  — inclure en haut de chaque page admin
// Nécessite que session_start() ait déjà été appelé et que $_SESSION['admin'] soit vrai
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ECO'LOC — Admin</title>
    <link rel="stylesheet" href="admin_style.css">
</head>
<body>
<nav>
    <span class="logo">ECO'LOC — Administration</span>
    <a href="adminDashboard.php"      <?= basename($_SERVER['PHP_SELF']) === 'adminDashboard.php'      ? 'class="active"' : '' ?>>Tableau de bord</a>
    <a href="adminValidationComptes.php" <?= basename($_SERVER['PHP_SELF']) === 'adminValidationComptes.php' ? 'class="active"' : '' ?>>Validation comptes</a>
    <a href="adminGestionAbonnes.php" <?= basename($_SERVER['PHP_SELF']) === 'adminGestionAbonnes.php' ? 'class="active"' : '' ?>>Abonnés</a>
    <a href="adminGestionMateriel.php"<?= basename($_SERVER['PHP_SELF']) === 'adminGestionMateriel.php'? 'class="active"' : '' ?>>Matériels</a>
    <a href="adminGestionEmprunts.php"<?= basename($_SERVER['PHP_SELF']) === 'adminGestionEmprunts.php'? 'class="active"' : '' ?>>Emprunts</a>
    <a href="adminAjouterCategorie.php"<?= basename($_SERVER['PHP_SELF']) === 'adminAjouterCategorie.php'? 'class="active"' : '' ?>>Catégories</a>
    <a href="../logout.php" class="logout">Déconnexion</a>
</nav>
<main>
