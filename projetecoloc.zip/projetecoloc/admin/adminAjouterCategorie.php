<?php
session_start();
require_once "../model/dao/CategorieDAO.php";

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: ../login.php");
    exit;
}

$erreur  = "";
$succes  = "";

// Ajout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['libelle'])) {
    $libelle = trim($_POST['libelle']);
    if (empty($libelle)) {
        $erreur = "Le libellé est obligatoire.";
    } else {
        CategorieDAO::create($libelle);
        $succes = "Catégorie \"" . htmlspecialchars($libelle) . "\" ajoutée avec succès.";
    }
}

if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'supprimer') {
    $id = (int)$_GET['id'];
    if ($id > 0) {
        CategorieDAO::delete($id);
        $succes = "Catégorie supprimée.";
    }
}

$categories = CategorieDAO::getAll();

include '_nav.php';
?>

<h1>Gestion des catégories</h1>

<?php if ($erreur): ?>
    <div class="alert alert-error"><?= htmlspecialchars($erreur) ?></div>
<?php endif; ?>
<?php if ($succes): ?>
    <div class="alert alert-success"><?= $succes ?></div>
<?php endif; ?>


<div class="card" style="max-width:480px;">
    <h2 style="margin-bottom:14px;">Ajouter une catégorie</h2>
    <form method="POST">
        <label>Libellé de la catégorie *</label>
        <input type="text" name="libelle" placeholder="Ex : Outillage, Jardinage…" required>
        <button type="submit" class="btn btn-success" style="margin-top:14px;">Ajouter</button>
    </form>
</div>

<div class="card">
    <h2 style="margin-bottom:14px;">Catégories existantes (<?= count($categories) ?>)</h2>
    <?php if (empty($categories)): ?>
        <p>Aucune catégorie enregistrée.</p>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Libellé</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($categories as $cat): ?>
            <tr>
                <td><?= $cat->getId() ?></td>
                <td><?= htmlspecialchars($cat->getLibelle()) ?></td>
                <td>
                    <a href="?action=supprimer&id=<?= $cat->getId() ?>"
                       class="btn btn-danger btn-sm"
                       onclick="return confirm('Supprimer cette catégorie ? Les matériels associés seront affectés.')">
                        Supprimer
                    </a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include '_footer.php'; ?>
