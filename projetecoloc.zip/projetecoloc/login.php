<?php
session_start();
require_once __DIR__ . "/model/dao/AbonneDAO.php";

// Détection automatique du sous-dossier projet
$parts       = explode('/', trim($_SERVER['SCRIPT_NAME'], '/'));
$BASE        = '/' . $parts[0]; // ex: /projete

// Déjà connecté → redirect
if (isset($_SESSION['id_utilisateur'])) {
    header("Location: $BASE/abonne/profil.php");
    exit;
}
if (isset($_SESSION['admin'])) {
    header("Location: $BASE/admin/adminDashboard.php");
    exit;
}

define('ADMIN_EMAIL',    'admin@ecoloc.fr');
define('ADMIN_PASSWORD', 'admin1234');

$erreur = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']    ?? '');
    $mdp   =       $_POST['password'] ?? '';

    if (empty($email) || empty($mdp)) {
        $erreur = "Veuillez remplir tous les champs.";
    } elseif ($email === ADMIN_EMAIL && $mdp === ADMIN_PASSWORD) {
        $_SESSION['admin'] = true;
        header("Location: $BASE/admin/adminDashboard.php");
        exit;
    } else {
        $row = AbonneDAO::authenticate($email, $mdp);

        if (!$row) {
            $erreur = "Email ou mot de passe incorrect.";
        } elseif ($row['role'] === 'admin') {
            $_SESSION['admin'] = true;
            header("Location: $BASE/admin/adminDashboard.php");
            exit;
        } elseif ($row['statut'] === 'en_attente') {
            $erreur = "Votre compte est en attente de validation par un administrateur.";
        } else {
            $_SESSION['id_utilisateur'] = $row['id_utilisateur'];
            $abonne = AbonneDAO::getById($row['id_utilisateur']);
            $_SESSION['prenom'] = $abonne ? $abonne->getPrenom() : '';
            header("Location: $BASE/abonne/profil.php");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion — ECO'LOC</title>
    <link rel="stylesheet" href="<?= $BASE ?>/style.css">
</head>
<body>
<nav>
    <a href="<?= $BASE ?>/index.php" class="logo">ECO'LOC</a>
    <a href="<?= $BASE ?>/index.php?page=catalogue">Catalogue</a>
    <a href="<?= $BASE ?>/index.php?page=inscription">S'inscrire</a>
    <a href="<?= $BASE ?>/login.php" class="active">Connexion</a>
</nav>
<main>

<h1>Connexion</h1>

<?php if ($erreur): ?>
    <div class="alert alert-error"><?= htmlspecialchars($erreur) ?></div>
<?php endif; ?>

<div class="card" style="max-width:420px;">
    <form method="POST">
        <label>Adresse email</label>
        <input type="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required autofocus>

        <label>Mot de passe</label>
        <input type="password" name="password" required>

        <button type="submit" class="btn btn-success" style="margin-top:16px;width:100%;">Se connecter</button>
    </form>

    <p style="margin-top:14px;font-size:0.88em;color:#666;">
        Pas encore de compte ? <a href="<?= $BASE ?>/index.php?page=inscription">S'inscrire</a>
    </p>
</div>

</main>
<footer>&copy; <?= date('Y') ?> ECO'LOC</footer>
</body>
</html>
