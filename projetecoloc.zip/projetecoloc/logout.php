<?php
session_start();
session_destroy();
$parts = explode('/', trim($_SERVER['SCRIPT_NAME'], '/'));
$BASE  = '/' . $parts[0];
header("Location: $BASE/login.php");
exit;
