<?php
if (!defined('BASE')) {
    $__parts = explode('/', trim(str_replace('\\', '/', $_SERVER['SCRIPT_NAME']), '/'));
    define('BASE', '/' . $__parts[0]);
}
