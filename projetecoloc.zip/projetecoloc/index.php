<?php
session_start();
require_once __DIR__ . "/controller/PublicController.php";

$page       = $_GET['page'] ?? 'catalogue';
$controller = new PublicController();

switch ($page) {
    case 'catalogue':
        $controller->catalogue();
        break;
    case 'detail':
        $controller->detail($_GET['id'] ?? null);
        break;
    case 'inscription':
        $controller->inscription();
        break;
    default:
        $controller->catalogue();
}
