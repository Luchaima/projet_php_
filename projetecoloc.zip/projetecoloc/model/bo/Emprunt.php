<?php

class Emprunt {
    private int $id;
    private int $idMateriel;
    private int $idEmprunteur;
    private string $dateDebut;
    private ?string $dateFin;
    private string $statut; // en_attente | en_cours | termine

    public function __construct($id, $idMateriel, $idEmprunteur, $dateDebut, $dateFin, $statut) {
        $this->id           = $id;
        $this->idMateriel   = $idMateriel;
        $this->idEmprunteur = $idEmprunteur;
        $this->dateDebut    = $dateDebut;
        $this->dateFin      = $dateFin;
        $this->statut       = $statut;
    }

    public function getId()           { return $this->id; }
    public function getIdMateriel()   { return $this->idMateriel; }
    public function getIdEmprunteur() { return $this->idEmprunteur; }
    public function getDateDebut()    { return $this->dateDebut; }
    public function getDateFin()      { return $this->dateFin; }
    public function getStatut()       { return $this->statut; }
}