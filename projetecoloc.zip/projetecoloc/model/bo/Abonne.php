<?php

class Abonne {
    private int $id;
    private string $nom;
    private string $prenom;
    private string $email;
    private string $telephone;
    private string $adresse;
    private string $statut; // en_attente | valide

    public function __construct($id, $nom, $prenom, $email, $telephone, $adresse, $statut) {
        $this->id        = $id;
        $this->nom       = $nom;
        $this->prenom    = $prenom;
        $this->email     = $email;
        $this->telephone = $telephone;
        $this->adresse   = $adresse;
        $this->statut    = $statut;
    }

    public function getId()        { return $this->id; }
    public function getNom()       { return $this->nom; }
    public function getPrenom()    { return $this->prenom; }
    public function getEmail()     { return $this->email; }
    public function getTelephone() { return $this->telephone; }
    public function getAdresse()   { return $this->adresse; }
    public function getStatut()    { return $this->statut; }
}