<?php

class Materiel {
    private int $id;
    private string $nom;
    private int $idCategorie;
    private string $caracteristique;
    private int $dureeMax;
    private bool $disponible;
    private string $etat;
    private int $idProprietaire;

    public function __construct($id, $nom, $idCategorie, $caracteristique, $dureeMax, $disponible, $etat, $idProprietaire) {
        $this->id              = $id;
        $this->nom             = $nom;
        $this->idCategorie     = $idCategorie;
        $this->caracteristique = $caracteristique;
        $this->dureeMax        = $dureeMax;
        $this->disponible      = $disponible;
        $this->etat            = $etat;
        $this->idProprietaire  = $idProprietaire;
    }

    public function getId()              { return $this->id; }
    public function getNom()             { return $this->nom; }
    public function getIdCategorie()     { return $this->idCategorie; }
    public function getCaracteristique() { return $this->caracteristique; }
    public function getDureeMax()        { return $this->dureeMax; }
    public function isDisponible()       { return $this->disponible; }
    public function getEtat()            { return $this->etat; }
    public function getIdProprietaire()  { return $this->idProprietaire; }
}