<?php

class Database {
    private static string $host = "localhost";
    private static string $db   = "ecoloc";
    private static string $user = "root";
    private static string $pass = "";
    private static $pdo = null;

    public static function getConnection() {
        if (self::$pdo === null) {
            try {
                self::$pdo = new PDO(
                    "mysql:host=" . self::$host . ";dbname=" . self::$db . ";charset=utf8",
                    self::$user,
                    self::$pass,
                    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
                );
            } catch (PDOException $e) {
                die("Erreur BDD : " . $e->getMessage());
            }
        }
        return self::$pdo;
    }
}