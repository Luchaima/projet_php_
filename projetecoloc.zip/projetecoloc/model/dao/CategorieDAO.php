<?php

require_once "Database.php";
require_once __DIR__ . "/../bo/Categorie.php";

class CategorieDAO {

    public static function getAll() {
        $pdo   = Database::getConnection();
        $stmt  = $pdo->query("SELECT * FROM categorie ORDER BY libelle");
        $list  = [];
        while ($row = $stmt->fetch()) {
            $list[] = new Categorie($row["id_categorie"], $row["libelle"]);
        }
        return $list;
    }

    public static function getById($id) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare("SELECT * FROM categorie WHERE id_categorie = ?");
        $stmt->execute([$id]);
        $row  = $stmt->fetch();
        if (!$row) return null;
        return new Categorie($row["id_categorie"], $row["libelle"]);
    }

    public static function create($libelle) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare("INSERT INTO categorie (libelle) VALUES (?)");
        $stmt->execute([$libelle]);
    }

    public static function delete($id) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare("DELETE FROM categorie WHERE id_categorie = ?");
        $stmt->execute([$id]);
    }
}
