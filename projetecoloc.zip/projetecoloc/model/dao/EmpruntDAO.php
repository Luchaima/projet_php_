<?php

require_once "Database.php";
require_once __DIR__ . "/../bo/Emprunt.php";

class EmpruntDAO {

    private static function rowToEmprunt($row) {
        return new Emprunt(
            $row["id_emprunt"],
            $row["id_materiel"],
            $row["id_emprunteur"],
            $row["date_debut"],
            $row["date_fin"],
            $row["statut"]
        );
    }

    public static function getAll() {
        $pdo  = Database::getConnection();
        $stmt = $pdo->query("SELECT * FROM emprunt ORDER BY date_debut DESC");
        $list = [];
        while ($row = $stmt->fetch()) {
            $list[] = self::rowToEmprunt($row);
        }
        return $list;
    }

    public static function getById($id) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare("SELECT * FROM emprunt WHERE id_emprunt = ?");
        $stmt->execute([$id]);
        $row  = $stmt->fetch();
        if (!$row) return null;
        return self::rowToEmprunt($row);
    }

    /** Alias utilisé dans emprunt_valider.php */
    public static function getDemandeById($id) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare("SELECT * FROM emprunt WHERE id_emprunt = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(); // retourne un tableau brut
    }

    public static function getByMateriel($idMateriel) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare("SELECT * FROM emprunt WHERE id_materiel = ?");
        $stmt->execute([$idMateriel]);
        $list = [];
        while ($row = $stmt->fetch()) {
            $list[] = self::rowToEmprunt($row);
        }
        return $list;
    }

    public static function getByEmprunteur($idEmprunteur) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare("SELECT * FROM emprunt WHERE id_emprunteur = ?");
        $stmt->execute([$idEmprunteur]);
        $list = [];
        while ($row = $stmt->fetch()) {
            $list[] = self::rowToEmprunt($row);
        }
        return $list;
    }

    /** Demandes reçues pour les matériels d'un propriétaire */
    public static function getDemandesRecues($idProprietaire) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare(
            "SELECT e.* FROM emprunt e
             JOIN materiel m ON e.id_materiel = m.id_materiel
             WHERE m.id_proprietaire = ?
             ORDER BY e.date_debut DESC"
        );
        $stmt->execute([$idProprietaire]);
        $list = [];
        while ($row = $stmt->fetch()) {
            $list[] = self::rowToEmprunt($row);
        }
        return $list;
    }

    public static function isMaterielDisponible($idMateriel) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM emprunt WHERE id_materiel = ? AND statut = 'en_cours'");
        $stmt->execute([$idMateriel]);
        return $stmt->fetchColumn() == 0;
    }

    /** Créer une demande d'emprunt (statut en_attente) */
    public static function creerDemande($idMateriel, $idEmprunteur, $dateDebut, $dateFin) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare(
            "INSERT INTO emprunt (id_materiel, id_emprunteur, date_debut, date_fin, statut)
             VALUES (?, ?, ?, ?, 'en_attente')"
        );
        $stmt->execute([$idMateriel, $idEmprunteur, $dateDebut, $dateFin]);
    }

    /** Accepter une demande : passe en_cours + marque matériel indisponible */
    public static function validerDemande($id) {
        $pdo = Database::getConnection();

        $stmt = $pdo->prepare("UPDATE emprunt SET statut = 'en_cours' WHERE id_emprunt = ?");
        $stmt->execute([$id]);

        // Récupérer le matériel associé pour le marquer indisponible
        $row  = $pdo->prepare("SELECT id_materiel FROM emprunt WHERE id_emprunt = ?");
        $row->execute([$id]);
        $data = $row->fetch();
        if ($data) {
            $upd = $pdo->prepare("UPDATE materiel SET disponible = 0 WHERE id_materiel = ?");
            $upd->execute([$data['id_materiel']]);
        }
    }

    /** Refuser une demande */
    public static function refuserDemande($id) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare("UPDATE emprunt SET statut = 'refuse' WHERE id_emprunt = ?");
        $stmt->execute([$id]);
    }

    /** Admin : clôturer un emprunt en cours */
    public static function cloturerEmprunt($id) {
        $pdo = Database::getConnection();

        // Récupérer le matériel pour le remettre disponible
        $row  = $pdo->prepare("SELECT id_materiel FROM emprunt WHERE id_emprunt = ?");
        $row->execute([$id]);
        $data = $row->fetch();

        $stmt = $pdo->prepare("UPDATE emprunt SET statut = 'termine', date_fin = CURDATE() WHERE id_emprunt = ?");
        $stmt->execute([$id]);

        if ($data) {
            $upd = $pdo->prepare("UPDATE materiel SET disponible = 1 WHERE id_materiel = ?");
            $upd->execute([$data['id_materiel']]);
        }
    }
}
