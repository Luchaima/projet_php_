<?php

require_once "Database.php";
require_once __DIR__ . "/../bo/Abonne.php";

class AbonneDAO {

    private static function rowToAbonne($row) {
        return new Abonne(
            $row["id_utilisateur"],
            $row["nom"],
            $row["prenom"],
            $row["email"],
            $row["telephone"],
            $row["adresse"],
            $row["role"] === 'admin' ? 'valide' : 'valide' // tout le monde dans utilisateur est validé
        );
    }

    public static function getAll() {
        $pdo  = Database::getConnection();
        $stmt = $pdo->query("SELECT * FROM utilisateur WHERE role = 'abonne'");
        $result = [];
        while ($row = $stmt->fetch()) {
            $result[] = self::rowToAbonne($row);
        }
        return $result;
    }

    public static function getById($id) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare("SELECT * FROM utilisateur WHERE id_utilisateur = ?");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        if (!$row) return null;
        return self::rowToAbonne($row);
    }

    public static function create($nom, $prenom, $email, $telephone, $adresse, $motDePasse) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare(
            "INSERT INTO utilisateur (nom, prenom, email, telephone, adresse, mot_de_passe, role)
             VALUES (?, ?, ?, ?, ?, ?, 'abonne')"
        );
        $stmt->execute([$nom, $prenom, $email, $telephone, $adresse, $motDePasse]);
    }

    public static function update($id, $nom, $prenom, $telephone, $adresse) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare(
            "UPDATE utilisateur SET nom=?, prenom=?, telephone=?, adresse=? WHERE id_utilisateur=?"
        );
        $stmt->execute([$nom, $prenom, $telephone, $adresse, $id]);
    }

    public static function delete($id) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare("DELETE FROM utilisateur WHERE id_utilisateur = ?");
        $stmt->execute([$id]);
    }

    public static function authenticate($email, $motDePasse) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare("SELECT * FROM utilisateur WHERE email = ?");
        $stmt->execute([$email]);
        $row = $stmt->fetch();

        if (!$row) return null;

        // Supporte mots de passe en clair ET hashés bcrypt
        $ok = password_verify($motDePasse, $row['mot_de_passe'])
           || $motDePasse === $row['mot_de_passe'];

        if (!$ok) return null;

        
        return [
            'id_utilisateur' => $row['id_utilisateur'],
            'mot_de_passe'   => $row['mot_de_passe'],
            'statut'         => 'valide', // pas de statut dans ta BDD, on considère tout validé
            'role'           => $row['role'],
        ];
    }

    
    public static function validerCompte($id) {
        
    }
    public static function refuserCompte($id) {
        self::delete($id);
    }
}
