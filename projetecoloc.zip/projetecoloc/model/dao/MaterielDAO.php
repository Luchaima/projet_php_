<?php

require_once "Database.php";
require_once __DIR__ . "/../bo/Materiel.php";

class MaterielDAO {

    private static function rowToMateriel($row) {
        return new Materiel(
            $row["id_materiel"],
            $row["nom"],
            $row["id_categorie"],
            $row["caracteristique"],
            $row["duree_pret_max"],
            (bool)$row["disponible"],
            $row["etat"],
            $row["id_proprietaire"]
        );
    }

    public static function getAll() {
        $pdo   = Database::getConnection();
        $stmt  = $pdo->query("SELECT * FROM materiel");
        $list  = [];
        while ($row = $stmt->fetch()) {
            $list[] = self::rowToMateriel($row);
        }
        return $list;
    }

    public static function getAllDisponible() {
        $pdo   = Database::getConnection();
        $stmt  = $pdo->query("SELECT * FROM materiel WHERE disponible = 1");
        $list  = [];
        while ($row = $stmt->fetch()) {
            $list[] = self::rowToMateriel($row);
        }
        return $list;
    }

    public static function getById($id) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare("SELECT * FROM materiel WHERE id_materiel = ?");
        $stmt->execute([$id]);
        $row  = $stmt->fetch();
        if (!$row) return null;
        return self::rowToMateriel($row);
    }

    public static function getByProprietaire($idProp) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare("SELECT * FROM materiel WHERE id_proprietaire = ?");
        $stmt->execute([$idProp]);
        $list = [];
        while ($row = $stmt->fetch()) {
            $list[] = self::rowToMateriel($row);
        }
        return $list;
    }

    public static function getByCategorie($idCat) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare("SELECT * FROM materiel WHERE id_categorie = ? AND disponible = 1");
        $stmt->execute([$idCat]);
        $list = [];
        while ($row = $stmt->fetch()) {
            $list[] = self::rowToMateriel($row);
        }
        return $list;
    }

    public static function isDisponible($id) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare("SELECT disponible FROM materiel WHERE id_materiel = ?");
        $stmt->execute([$id]);
        $row  = $stmt->fetch();
        return $row && (bool)$row['disponible'];
    }

    public static function setDisponible($id, bool $dispo) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare("UPDATE materiel SET disponible = ? WHERE id_materiel = ?");
        $stmt->execute([$dispo ? 1 : 0, $id]);
    }

    public static function create($nom, $idCategorie, $caracteristique, $dureeMax, $etat, $idProprietaire) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare("INSERT INTO materiel (nom, id_categorie, caracteristique, duree_pret_max, etat, disponible, id_proprietaire)
                               VALUES (?, ?, ?, ?, ?, 1, ?)");
        $stmt->execute([$nom, $idCategorie, $caracteristique, $dureeMax, $etat, $idProprietaire]);
    }

    public static function update($id, $nom, $idCategorie, $caracteristique, $dureeMax, $etat) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare(
            "UPDATE materiel SET nom=?, id_categorie=?, caracteristique=?, duree_pret_max=?, etat=?
             WHERE id_materiel=?"
        );
        $stmt->execute([$nom, $idCategorie, $caracteristique, $dureeMax, $etat, $id]);
    }

    public static function delete($id) {
        $pdo  = Database::getConnection();
        $stmt = $pdo->prepare("DELETE FROM materiel WHERE id_materiel = ?");
        $stmt->execute([$id]);
    }
}
