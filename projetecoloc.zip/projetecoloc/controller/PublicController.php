<?php

require_once __DIR__ . "/../model/dao/MaterielDAO.php";
require_once __DIR__ . "/../model/dao/CategorieDAO.php";
require_once __DIR__ . "/../model/dao/AbonneDAO.php";

class PublicController {

    public function catalogue() {
        $idCat     = $_GET['cat'] ?? null;
        $materiels  = $idCat ? MaterielDAO::getByCategorie($idCat) : MaterielDAO::getAllDisponible();
        $categories = CategorieDAO::getAll();

        include __DIR__ . "/../view/templates/header.php";
        include __DIR__ . "/../view/public/catalogue.php";
        include __DIR__ . "/../view/templates/footer.php";
    }

    public function detail($id) {
        if (!$id) {
            header("Location: /index.php?page=catalogue");
            exit;
        }

        $materiel = MaterielDAO::getById($id);
        if (!$materiel) {
            header("Location: /index.php?page=catalogue");
            exit;
        }

        $categorie = CategorieDAO::getById($materiel->getIdCategorie());

        include __DIR__ . "/../view/templates/header.php";
        include __DIR__ . "/../view/public/detailMateriel.php";
        include __DIR__ . "/../view/templates/footer.php";
    }

    public function inscription() {
        $erreur = null;
        $succes = false;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nom       = trim($_POST['nom']           ?? '');
            $prenom    = trim($_POST['prenom']         ?? '');
            $email     = trim($_POST['email']          ?? '');
            $telephone = trim($_POST['telephone']      ?? '');
            $adresse   = trim($_POST['adresse']        ?? '');
            $mdp       =       $_POST['mot_de_passe']  ?? '';

            if (!$nom || !$prenom || !$email || !$mdp) {
                $erreur = "Veuillez remplir tous les champs obligatoires.";
            } else {
                AbonneDAO::create($nom, $prenom, $email, $telephone, $adresse, $mdp);
                $succes = true;
            }
        }

        include __DIR__ . "/../view/templates/header.php";
        include __DIR__ . "/../view/public/inscription.php";
        include __DIR__ . "/../view/templates/footer.php";
    }
}
