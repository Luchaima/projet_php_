<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once "../model/dao/EmpruntDAO.php";
require_once "../model/dao/MaterielDAO.php";

if (!isset($_SESSION['id_utilisateur'])) {
header('Location: ' . BASE . '/login.php'); exit;
}

$id       = $_SESSION['id_utilisateur'];
$emprunts = EmpruntDAO::getByEmprunteur($id);

$statutLabels = [
    'en_attente' => ['label' => 'En attente',  'badge' => 'badge-orange'],
    'en_cours'   => ['label' => 'En cours',    'badge' => 'badge-green'],
    'termine'    => ['label' => 'Terminé',     'badge' => 'badge-grey'],
    'refuse'     => ['label' => 'Refusé',      'badge' => 'badge-red'],
];

include "../view/templates/header.php";
?>

<h1>Mes emprunts</h1>

<?php if (empty($emprunts)): ?>
    <div class="alert alert-info">
        Vous n'avez pas encore effectué de demande d'emprunt.
        <a href="/index.php?page=catalogue">Parcourir le catalogue</a>
    </div>
<?php else: ?>
<div class="card">
    <table>
        <thead>
            <tr>
                <th>Matériel (ID)</th>
                <th>Date début</th>
                <th>Date fin</th>
                <th>Statut</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($emprunts as $e):
            $st = $statutLabels[$e->getStatut()] ?? ['label' => $e->getStatut(), 'badge' => 'badge-grey'];
        ?>
            <tr>
                <td>
                    <?php
                    $mat = MaterielDAO::getById($e->getIdMateriel());
                    echo $mat ? htmlspecialchars($mat->getNom()) : '#' . $e->getIdMateriel();
                    ?>
                </td>
                <td><?= htmlspecialchars($e->getDateDebut()) ?></td>
                <td><?= htmlspecialchars($e->getDateFin() ?? '—') ?></td>
                <td><span class="badge <?= $st['badge'] ?>"><?= $st['label'] ?></span></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php include "../view/templates/footer.php"; ?>
