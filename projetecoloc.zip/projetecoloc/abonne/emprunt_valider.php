<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once "../model/dao/EmpruntDAO.php";
require_once "../model/dao/MaterielDAO.php";

if (!isset($_SESSION['id_utilisateur'])) {
header('Location: ' . BASE . '/login.php'); exit;
}

$idDemande = (int)($_GET['id']     ?? 0);
$action    =       $_GET['action'] ?? '';

if ($idDemande <= 0 || !in_array($action, ['accepter', 'refuser'])) {
    $_SESSION['erreur'] = "Paramètres invalides.";
    header("Location: emprunts_recus.php");
    exit;
}

if ($action === 'accepter') {
    $demande = EmpruntDAO::getDemandeById($idDemande);

    if ($demande && MaterielDAO::isDisponible($demande['id_materiel'])) {
        EmpruntDAO::validerDemande($idDemande);
        $_SESSION['message'] = "Demande acceptée avec succès.";
    } else {
        $_SESSION['erreur'] = "Ce matériel n'est plus disponible, impossible d'accepter la demande.";
    }
} else {
    EmpruntDAO::refuserDemande($idDemande);
    $_SESSION['message'] = "Demande refusée.";
}

header("Location: emprunts_recus.php");
exit;
