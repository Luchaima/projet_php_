<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once "../model/dao/MaterielDAO.php";

if (!isset($_SESSION['id_utilisateur'])) {
header('Location: ' . BASE . '/login.php'); exit;
}

$id       = (int)($_GET['id'] ?? 0);
$materiel = MaterielDAO::getById($id);

if (!$materiel || $materiel->getIdProprietaire() !== $_SESSION['id_utilisateur']) {
    $_SESSION['message'] = "Matériel introuvable ou accès refusé.";
    header("Location: materiel_list.php");
    exit;
}

// Supprimer le matériel
MaterielDAO::delete($id);
$_SESSION['message'] = "Matériel supprimé avec succès.";

header("Location: materiel_list.php");
exit;
