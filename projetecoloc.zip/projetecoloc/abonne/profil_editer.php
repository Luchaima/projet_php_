<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once "../model/dao/AbonneDAO.php";

if (!isset($_SESSION['id_utilisateur'])) {
header('Location: ' . BASE . '/login.php'); exit;
}

$id     = $_SESSION['id_utilisateur'];
$abonne = AbonneDAO::getById($id);
$erreur = "";
$succes = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom       = trim($_POST['nom']);
    $prenom    = trim($_POST['prenom']);
    $telephone = trim($_POST['telephone']);
    $adresse   = trim($_POST['adresse']);

    if (empty($nom) || empty($prenom)) {
        $erreur = "Le nom et le prénom sont obligatoires.";
    } else {
        AbonneDAO::update($id, $nom, $prenom, $telephone, $adresse);
        $_SESSION['prenom'] = $prenom;
        $succes = "Profil mis à jour avec succès !";
        $abonne = AbonneDAO::getById($id);
    }
}

include "../view/templates/header.php";
?>

<h1>Modifier mon profil</h1>

<?php if ($erreur): ?>
    <div class="alert alert-error"><?= htmlspecialchars($erreur) ?></div>
<?php endif; ?>
<?php if ($succes): ?>
    <div class="alert alert-success"><?= htmlspecialchars($succes) ?></div>
<?php endif; ?>

<div class="card" style="max-width:480px;">
    <form method="POST">
        <label>Nom *</label>
        <input type="text" name="nom" value="<?= htmlspecialchars($abonne->getNom()) ?>" required>

        <label>Prénom *</label>
        <input type="text" name="prenom" value="<?= htmlspecialchars($abonne->getPrenom()) ?>" required>

        <label>Téléphone</label>
        <input type="text" name="telephone" value="<?= htmlspecialchars($abonne->getTelephone()) ?>">

        <label>Adresse</label>
        <input type="text" name="adresse" value="<?= htmlspecialchars($abonne->getAdresse()) ?>">

        <div style="display:flex;gap:10px;margin-top:20px;">
            <button type="submit" class="btn btn-success">Enregistrer</button>
            <a href="profil.php" class="btn btn-grey">← Annuler</a>
        </div>
    </form>
</div>

<?php include "../view/templates/footer.php"; ?>
