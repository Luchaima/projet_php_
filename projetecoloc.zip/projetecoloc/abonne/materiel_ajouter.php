<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once "../model/dao/MaterielDAO.php";
require_once "../model/dao/CategorieDAO.php";

if (!isset($_SESSION['id_utilisateur'])) {
header('Location: ' . BASE . '/login.php'); exit;
}

$erreur     = "";
$categories = CategorieDAO::getAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom             = trim($_POST['nom']);
    $idCategorie     = (int)$_POST['id_categorie'];
    $caracteristique = trim($_POST['caracteristique']);
    $dureeMax        = (int)$_POST['duree_pret_max'];
    $etat            = $_POST['etat'];
    $idProprietaire  = $_SESSION['id_utilisateur'];

    if (empty($nom) || $idCategorie <= 0 || $dureeMax <= 0) {
        $erreur = "Veuillez remplir tous les champs obligatoires.";
    } else {
        MaterielDAO::create($nom, $idCategorie, $caracteristique, $dureeMax, $etat, $idProprietaire);
        $_SESSION['message'] = "Matériel ajouté avec succès !";
        header("Location: materiel_list.php");
        exit;
    }
}

include "../view/templates/header.php";
?>

<h1> Ajouter un matériel</h1>

<?php if ($erreur): ?>
    <div class="alert alert-error"><?= htmlspecialchars($erreur) ?></div>
<?php endif; ?>

<div class="card" style="max-width:560px;">
    <form method="POST">
        <label>Nom du matériel *</label>
        <input type="text" name="nom" placeholder="Ex : Perceuse, Échelle, Vélo…" required>

        <label>Catégorie *</label>
        <select name="id_categorie" required>
            <option value="">-- Choisir une catégorie --</option>
            <?php foreach ($categories as $cat): ?>
                <option value="<?= $cat->getId() ?>"><?= htmlspecialchars($cat->getLibelle()) ?></option>
            <?php endforeach; ?>
        </select>

        <label>Caractéristiques</label>
        <textarea name="caracteristique" placeholder="Description, dimensions, poids…"></textarea>

        <label>Durée de prêt maximum (jours) *</label>
        <input type="number" name="duree_pret_max" value="7" min="1" required>

        <label>État du matériel *</label>
        <select name="etat" required>
            <option value="neuf">Neuf</option>
            <option value="bon" selected>Bon état</option>
            <option value="moyen">État correct</option>
            <option value="abime">Abîmé</option>
        </select>

        <div style="display:flex;gap:10px;margin-top:20px;">
            <button type="submit" class="btn btn-success"> Ajouter le matériel</button>
            <a href="materiel_list.php" class="btn btn-grey">← Annuler</a>
        </div>
    </form>
</div>

<?php include "../view/templates/footer.php"; ?>
