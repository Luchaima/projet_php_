<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once "../model/dao/MaterielDAO.php";
require_once "../model/dao/CategorieDAO.php";

if (!isset($_SESSION['id_utilisateur'])) {
header('Location: ' . BASE . '/login.php'); exit;
}

$id       = (int)($_GET['id'] ?? 0);
$materiel = MaterielDAO::getById($id);

if (!$materiel || $materiel->getIdProprietaire() !== $_SESSION['id_utilisateur']) {
    echo "Matériel introuvable ou accès refusé.";
    exit;
}

$erreur     = "";
$categories = CategorieDAO::getAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom             = trim($_POST['nom']);
    $idCategorie     = (int)$_POST['id_categorie'];
    $caracteristique = trim($_POST['caracteristique']);
    $dureeMax        = (int)$_POST['duree_pret_max'];
    $etat            = $_POST['etat'];

    if (empty($nom) || $idCategorie <= 0 || $dureeMax <= 0) {
        $erreur = "Veuillez remplir tous les champs obligatoires.";
    } else {
        MaterielDAO::update($id, $nom, $idCategorie, $caracteristique, $dureeMax, $etat);
        $_SESSION['message'] = "Matériel modifié avec succès.";
        header("Location: materiel_list.php");
        exit;
    }
}

include "../view/templates/header.php";
?>

<h1>Modifier un matériel</h1>

<?php if ($erreur): ?>
    <div class="alert alert-error"><?= htmlspecialchars($erreur) ?></div>
<?php endif; ?>

<div class="card" style="max-width:540px;">
    <form method="POST">
        <label>Nom du matériel *</label>
        <input type="text" name="nom"
               value="<?= htmlspecialchars($_POST['nom'] ?? $materiel->getNom()) ?>" required>

        <label>Catégorie *</label>
        <select name="id_categorie" required>
            <?php foreach ($categories as $cat): ?>
                <option value="<?= $cat->getId() ?>"
                    <?= ($cat->getId() === ($materiel->getIdCategorie())) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($cat->getLibelle()) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label>Caractéristiques</label>
        <textarea name="caracteristique"><?= htmlspecialchars($_POST['caracteristique'] ?? $materiel->getCaracteristique()) ?></textarea>

        <label>Durée de prêt max (jours) *</label>
        <input type="number" name="duree_pret_max"
               value="<?= (int)($_POST['duree_pret_max'] ?? $materiel->getDureeMax()) ?>" min="1" required>

        <label>État *</label>
        <select name="etat" required>
            <?php foreach (['neuf' => 'Neuf', 'bon' => 'Bon état', 'moyen' => 'État correct', 'abime' => 'Abîmé'] as $val => $lib): ?>
                <option value="<?= $val ?>"
                    <?= ($val === ($materiel->getEtat())) ? 'selected' : '' ?>><?= $lib ?></option>
            <?php endforeach; ?>
        </select>

        <div style="margin-top:16px;display:flex;gap:10px;">
            <button type="submit" class="btn btn-success">Enregistrer</button>
            <a href="materiel_list.php" class="btn btn-grey">Annuler</a>
        </div>
    </form>
</div>

<?php include "../view/templates/footer.php"; ?>
