<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once "../model/dao/MaterielDAO.php";
require_once "../model/dao/CategorieDAO.php";

if (!isset($_SESSION['id_utilisateur'])) {
header('Location: ' . BASE . '/login.php'); exit;
}

$id        = $_SESSION['id_utilisateur'];
$materiels = MaterielDAO::getByProprietaire($id);
$categories = CategorieDAO::getAll();
$catMap    = [];
foreach ($categories as $c) { $catMap[$c->getId()] = $c->getLibelle(); }

$message = $_SESSION['message'] ?? '';
unset($_SESSION['message']);

include "../view/templates/header.php";
?>

<h1>Mon matériel</h1>

<?php if ($message): ?>
    <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<div style="margin-bottom:16px;">
    <a href="materiel_ajouter.php" class="btn btn-success">+ Ajouter un matériel</a>
</div>

<?php if (empty($materiels)): ?>
    <div class="alert alert-info">Vous n'avez pas encore déposé de matériel. <a href="materiel_ajouter.php">En ajouter un</a>.</div>
<?php else: ?>
<div class="card">
    <table>
        <thead>
            <tr>
                <th>Nom</th>
                <th>Catégorie</th>
                <th>État</th>
                <th>Durée max</th>
                <th>Disponible</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($materiels as $m): ?>
            <tr>
                <td><?= htmlspecialchars($m->getNom()) ?></td>
                <td><?= htmlspecialchars($catMap[$m->getIdCategorie()] ?? '—') ?></td>
                <td><?= htmlspecialchars($m->getEtat()) ?></td>
                <td><?= $m->getDureeMax() ?> j</td>
                <td>
                    <?php if ($m->isDisponible()): ?>
                        <span class="badge badge-green">Oui</span>
                    <?php else: ?>
                        <span class="badge badge-red">Non</span>
                    <?php endif; ?>
                </td>
                <td style="white-space:nowrap;">
                    <a href="materiel_editer.php?id=<?= $m->getId() ?>" class="btn btn-warning btn-sm">Modifier</a>
                    <a href="materiel_supprimer.php?id=<?= $m->getId() ?>"
                       class="btn btn-danger btn-sm"
                       onclick="return confirm('Supprimer ce matériel ?')">Supprimer</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php include "../view/templates/footer.php"; ?>
