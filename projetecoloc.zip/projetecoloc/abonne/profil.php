<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once "../model/dao/AbonneDAO.php";
require_once "../model/dao/MaterielDAO.php";
require_once "../model/dao/EmpruntDAO.php";

if (!isset($_SESSION['id_utilisateur'])) {
header('Location: ' . BASE . '/login.php'); exit;
}

$id      = $_SESSION['id_utilisateur'];
$abonne  = AbonneDAO::getById($id);
$nbMat   = count(MaterielDAO::getByProprietaire($id));
$nbEmp   = count(EmpruntDAO::getByEmprunteur($id));

include "../view/templates/header.php";
?>

<h1>Mon profil</h1>

<div class="card" style="max-width:540px;">
    <table>
        <tr><td style="width:40%;font-weight:bold;padding:8px 0;">Nom</td>
            <td><?= htmlspecialchars($abonne->getNom()) ?></td></tr>
        <tr><td style="font-weight:bold;padding:8px 0;">Prénom</td>
            <td><?= htmlspecialchars($abonne->getPrenom()) ?></td></tr>
        <tr><td style="font-weight:bold;padding:8px 0;">Email</td>
            <td><?= htmlspecialchars($abonne->getEmail()) ?></td></tr>
        <tr><td style="font-weight:bold;padding:8px 0;">Téléphone</td>
            <td><?= htmlspecialchars($abonne->getTelephone() ?: '—') ?></td></tr>
        <tr><td style="font-weight:bold;padding:8px 0;">Adresse</td>
            <td><?= htmlspecialchars($abonne->getAdresse() ?: '—') ?></td></tr>
        <tr><td style="font-weight:bold;padding:8px 0;">Statut</td>
            <td>
                <?php if ($abonne->getStatut() === 'valide'): ?>
                    <span class="badge badge-green">Validé</span>
                <?php else: ?>
                    <span class="badge badge-orange">En attente</span>
                <?php endif; ?>
            </td></tr>
    </table>

    <div style="margin-top:16px;display:flex;gap:10px;">
        <a href="profil_editer.php" class="btn btn-primary">Modifier mon profil</a>
    </div>
</div>

<div style="display:flex;gap:16px;flex-wrap:wrap;margin-top:4px;">
    <div class="card" style="min-width:160px;text-align:center;">
        <div style="font-size:2em;font-weight:bold;color:#2c3e50;"><?= $nbMat ?></div>
        <div style="font-size:0.85em;color:#666;margin-top:4px;">Matériels déposés</div>
        <a href="materiel_list.php" class="btn btn-sm btn-primary" style="margin-top:10px;">Voir</a>
    </div>
    <div class="card" style="min-width:160px;text-align:center;">
        <div style="font-size:2em;font-weight:bold;color:#2c3e50;"><?= $nbEmp ?></div>
        <div style="font-size:0.85em;color:#666;margin-top:4px;">Mes emprunts</div>
        <a href="mes_emprunts.php" class="btn btn-sm btn-primary" style="margin-top:10px;">Voir</a>
    </div>
    <div class="card" style="min-width:160px;text-align:center;">
        <div style="font-size:1.4em;font-weight:bold;color:#2c3e50;">📥</div>
        <div style="font-size:0.85em;color:#666;margin-top:4px;">Demandes reçues</div>
        <a href="emprunts_recus.php" class="btn btn-sm btn-primary" style="margin-top:10px;">Voir</a>
    </div>
</div>

<?php include "../view/templates/footer.php"; ?>
