<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once "../model/dao/MaterielDAO.php";
require_once "../model/dao/EmpruntDAO.php";

if (!isset($_SESSION['id_utilisateur'])) {
header('Location: ' . BASE . '/login.php'); exit;
}

$idMateriel = (int)($_GET['id'] ?? 0);
$materiel   = MaterielDAO::getById($idMateriel);

if (!$materiel || !$materiel->isDisponible()) {
    header("Location: '/'.explode('/',trim($_SERVER['SCRIPT_NAME'],'/'))[0].'/index.php?page=catalogue");
    exit;
}

// Empêcher d'emprunter son propre matériel
if ($materiel->getIdProprietaire() === $_SESSION['id_utilisateur']) {
    echo "Vous ne pouvez pas emprunter votre propre matériel.";
    exit;
}

$erreur = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dateDebut = $_POST['date_debut'] ?? '';
    $dateFin   = $_POST['date_fin']   ?? '';

    if (empty($dateDebut) || empty($dateFin)) {
        $erreur = "Veuillez indiquer les dates de début et de fin.";
    } elseif ($dateFin <= $dateDebut) {
        $erreur = "La date de fin doit être après la date de début.";
    } else {
        $nbJours = (strtotime($dateFin) - strtotime($dateDebut)) / 86400;
        if ($nbJours > $materiel->getDureeMax()) {
            $erreur = "La durée dépasse la limite autorisée de {$materiel->getDureeMax()} jours.";
        } else {
            EmpruntDAO::creerDemande($idMateriel, $_SESSION['id_utilisateur'], $dateDebut, $dateFin);
            header("Location: mes_emprunts.php");
            exit;
        }
    }
}

include "../view/templates/header.php";
?>

<h1>Demande d'emprunt</h1>

<?php if ($erreur): ?>
    <div class="alert alert-error"><?= htmlspecialchars($erreur) ?></div>
<?php endif; ?>

<div class="card" style="max-width:460px;">
    <p style="margin-bottom:14px;">
        Matériel : <strong><?= htmlspecialchars($materiel->getNom()) ?></strong><br>
        Durée maximale : <strong><?= $materiel->getDureeMax() ?> jours</strong>
    </p>

    <form method="POST">
        <label>Date de début *</label>
        <input type="date" name="date_debut"
               value="<?= htmlspecialchars($_POST['date_debut'] ?? '') ?>"
               min="<?= date('Y-m-d') ?>" required>

        <label>Date de fin *</label>
        <input type="date" name="date_fin"
               value="<?= htmlspecialchars($_POST['date_fin'] ?? '') ?>"
               min="<?= date('Y-m-d', strtotime('+1 day')) ?>" required>

        <div style="margin-top:16px;display:flex;gap:10px;">
            <button type="submit" class="btn btn-success">Envoyer la demande</button>
            <a href="/index.php?page=detail&id=<?= $idMateriel ?>" class="btn btn-grey">Annuler</a>
        </div>
    </form>
</div>

<?php include "../view/templates/footer.php"; ?>
