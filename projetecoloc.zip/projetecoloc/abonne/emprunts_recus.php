<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once "../model/dao/EmpruntDAO.php";
require_once "../model/dao/MaterielDAO.php";
require_once "../model/dao/AbonneDAO.php";

if (!isset($_SESSION['id_utilisateur'])) {
header('Location: ' . BASE . '/login.php'); exit;
}

$id       = $_SESSION['id_utilisateur'];
$demandes = EmpruntDAO::getDemandesRecues($id);

// Maps pour affichage
$materiels = MaterielDAO::getByProprietaire($id);
$matMap = [];
foreach ($materiels as $m) { $matMap[$m->getId()] = $m; }

$message = $_SESSION['erreur'] ?? '';
unset($_SESSION['erreur']);

$statutLabels = [
    'en_attente' => ['label' => 'En attente',  'badge' => 'badge-orange'],
    'en_cours'   => ['label' => 'En cours',    'badge' => 'badge-green'],
    'termine'    => ['label' => 'Terminé',     'badge' => 'badge-grey'],
    'refuse'     => ['label' => 'Refusé',      'badge' => 'badge-red'],
];

include "../view/templates/header.php";
?>

<h1>Demandes d'emprunt reçues</h1>

<?php if ($message): ?>
    <div class="alert alert-error"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<?php if (empty($demandes)): ?>
    <div class="alert alert-info">Aucune demande reçue pour vos matériels.</div>
<?php else: ?>
<div class="card">
    <table>
        <thead>
            <tr>
                <th>Matériel</th>
                <th>Demandeur (ID)</th>
                <th>Date début</th>
                <th>Date fin</th>
                <th>Statut</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($demandes as $e):
            $mat = $matMap[$e->getIdMateriel()] ?? null;
            $st  = $statutLabels[$e->getStatut()] ?? ['label' => $e->getStatut(), 'badge' => 'badge-grey'];
        ?>
            <tr>
                <td><?= htmlspecialchars($mat ? $mat->getNom() : '—') ?></td>
                <td>#<?= $e->getIdEmprunteur() ?></td>
                <td><?= htmlspecialchars($e->getDateDebut()) ?></td>
                <td><?= htmlspecialchars($e->getDateFin() ?? '—') ?></td>
                <td><span class="badge <?= $st['badge'] ?>"><?= $st['label'] ?></span></td>
                <td style="white-space:nowrap;">
                    <?php if ($e->getStatut() === 'en_attente'): ?>
                        <a href="emprunt_valider.php?id=<?= $e->getId() ?>&action=accepter"
                           class="btn btn-success btn-sm"
                           onclick="return confirm('Accepter cette demande ?')">Accepter</a>
                        <a href="emprunt_valider.php?id=<?= $e->getId() ?>&action=refuser"
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Refuser cette demande ?')">Refuser</a>
                    <?php else: ?>
                        <span style="color:#aaa;font-size:0.8em;">—</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php include "../view/templates/footer.php"; ?>
