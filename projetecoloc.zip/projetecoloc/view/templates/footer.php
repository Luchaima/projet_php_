</main>
<footer>
    &copy; <?= date('Y') ?> ECO'LOC — Plateforme de prêt de matériel entre particuliers
</footer>
</body>
</html>
