<?php
$scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
$parts      = explode('/', trim($scriptName, '/'));
$BASE       = '/' . $parts[0];

if (!defined('BASE')) define('BASE', $BASE);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ECO'LOC</title>
    <link rel="stylesheet" href="<?= BASE ?>/style.css">
</head>
<body>
<nav>
    <a href="<?= BASE ?>/index.php" class="logo">ECO'LOC</a>
    <a href="<?= BASE ?>/index.php?page=catalogue"
       <?= (($_GET['page'] ?? 'catalogue') === 'catalogue') ? 'class="active"' : '' ?>>Catalogue</a>

    <?php if (isset($_SESSION['id_utilisateur'])): ?>
        <a href="<?= BASE ?>/abonne/profil.php"
           <?= str_contains($_SERVER['PHP_SELF'], 'profil') ? 'class="active"' : '' ?>>Mon profil</a>
        <a href="<?= BASE ?>/abonne/materiel_list.php"
           <?= str_contains($_SERVER['PHP_SELF'], 'materiel') ? 'class="active"' : '' ?>>Mon matériel</a>
        <a href="<?= BASE ?>/abonne/emprunts_recus.php"
           <?= str_contains($_SERVER['PHP_SELF'], 'emprunt') ? 'class="active"' : '' ?>>Emprunts</a>
        <a href="<?= BASE ?>/logout.php" class="logout">Déconnexion (<?= htmlspecialchars($_SESSION['prenom'] ?? '') ?>)</a>
    <?php elseif (isset($_SESSION['admin'])): ?>
        <a href="<?= BASE ?>/admin/adminDashboard.php">Administration</a>
        <a href="<?= BASE ?>/logout.php" class="logout">Déconnexion</a>
    <?php else: ?>
        <a href="<?= BASE ?>/index.php?page=inscription"
           <?= (($_GET['page'] ?? '') === 'inscription') ? 'class="active"' : '' ?>>S'inscrire</a>
        <a href="<?= BASE ?>/login.php" class="btn-nav">Connexion</a>
    <?php endif; ?>
</nav>
<main>
