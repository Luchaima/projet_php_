<?php
$erreur = $erreur ?? null;
$succes = $succes ?? false;
$base = defined('BASE') ? BASE : '';
?>

<h1>Créer un compte</h1>

<?php if ($succes): ?>
    <div class="alert alert-success">
        Votre compte a bien été créé. Vous pouvez maintenant vous connecter.
    </div>
    <a href="<?= $base ?>/login.php" class="btn btn-success">Se connecter</a>

<?php else: ?>

    <?php if ($erreur): ?>
        <div class="alert alert-error"><?= htmlspecialchars($erreur) ?></div>
    <?php endif; ?>

    <div class="card" style="max-width:480px;">
        <form method="POST" action="<?= $base ?>/index.php?page=inscription">
            <label>Nom *</label>
            <input type="text" name="nom" value="<?= htmlspecialchars($_POST['nom'] ?? '') ?>" required>

            <label>Prénom *</label>
            <input type="text" name="prenom" value="<?= htmlspecialchars($_POST['prenom'] ?? '') ?>" required>

            <label>Email *</label>
            <input type="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>

            <label>Téléphone</label>
            <input type="text" name="telephone" value="<?= htmlspecialchars($_POST['telephone'] ?? '') ?>">

            <label>Adresse</label>
            <textarea name="adresse"><?= htmlspecialchars($_POST['adresse'] ?? '') ?></textarea>

            <label>Mot de passe *</label>
            <input type="password" name="mot_de_passe" required>

            <button type="submit" class="btn btn-success" style="margin-top:16px;width:100%;">
                Créer mon compte
            </button>

            <p style="margin-top:12px;font-size:0.85em;color:#666;">
                Déjà inscrit ? <a href="<?= $base ?>/login.php">Se connecter</a>
            </p>
        </form>
    </div>

<?php endif; ?>
