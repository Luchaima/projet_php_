<?php
if (!isset($materiel)) $materiel = null;
if (!isset($categorie)) $categorie = null;
$base = defined('BASE') ? BASE : '';
?>

<?php if ($materiel === null): ?>
    <div class="alert alert-error">Matériel introuvable.</div>
    <a href="<?= $base ?>/index.php?page=catalogue" class="btn btn-grey">Retour au catalogue</a>
<?php else: ?>

<h1><?= htmlspecialchars($materiel->getNom()) ?></h1>

<div class="card" style="max-width:580px;">
    <table>
        <tr>
            <td style="font-weight:bold;padding:8px 0;width:38%;">Catégorie</td>
            <td><?= $categorie ? htmlspecialchars($categorie->getLibelle()) : '—' ?></td>
        </tr>
        <tr>
            <td style="font-weight:bold;padding:8px 0;">Caractéristiques</td>
            <td><?= htmlspecialchars($materiel->getCaracteristique() ?: '—') ?></td>
        </tr>
        <tr>
            <td style="font-weight:bold;padding:8px 0;">Durée max</td>
            <td><?= $materiel->getDureeMax() ?> jours</td>
        </tr>
        <tr>
            <td style="font-weight:bold;padding:8px 0;">État</td>
            <td><?= htmlspecialchars($materiel->getEtat()) ?></td>
        </tr>
        <tr>
            <td style="font-weight:bold;padding:8px 0;">Disponibilité</td>
            <td>
                <?php if ($materiel->isDisponible()): ?>
                    <span class="badge badge-green">Disponible</span>
                <?php else: ?>
                    <span class="badge badge-red">Indisponible</span>
                <?php endif; ?>
            </td>
        </tr>
    </table>

    <div style="margin-top:20px;display:flex;gap:10px;">
        <?php if ($materiel->isDisponible() && isset($_SESSION['id_utilisateur'])): ?>
            <a href="<?= $base ?>/abonne/emprunt_demander.php?id=<?= $materiel->getId() ?>"
               class="btn btn-success">Faire une demande d'emprunt</a>
        <?php elseif (!isset($_SESSION['id_utilisateur'])): ?>
            <a href="<?= $base ?>/login.php" class="btn btn-success">Se connecter pour emprunter</a>
        <?php endif; ?>
        <a href="<?= $base ?>/index.php?page=catalogue" class="btn btn-grey">← Retour au catalogue</a>
    </div>
</div>

<?php endif; ?>
