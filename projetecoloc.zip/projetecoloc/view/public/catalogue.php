<?php
$categories = $categories ?? [];
$materiels  = $materiels  ?? [];
$idCatActif = $_GET['cat'] ?? '';
$base = defined('BASE') ? BASE : '';
?>

<h1>Catalogue du matériel</h1>

<div class="filter-bar">
    <form method="GET" action="<?= $base ?>/index.php" style="display:contents;">
        <input type="hidden" name="page" value="catalogue">
        <label>Catégorie :</label>
        <select name="cat">
            <option value="">Toutes les catégories</option>
            <?php foreach ($categories as $cat): ?>
                <option value="<?= $cat->getId() ?>" <?= $idCatActif == $cat->getId() ? 'selected' : '' ?>>
                    <?= htmlspecialchars($cat->getLibelle()) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-primary">Filtrer</button>
        <?php if ($idCatActif): ?>
            <a href="<?= $base ?>/index.php?page=catalogue" class="btn btn-grey">✕ Tout afficher</a>
        <?php endif; ?>
    </form>
</div>

<?php if (empty($materiels)): ?>
    <div class="alert alert-info">Aucun matériel disponible pour le moment.</div>
<?php else: ?>
    <div class="grid">
        <?php foreach ($materiels as $m): ?>
        <div class="grid-item">
            <h3><?= htmlspecialchars($m->getNom()) ?></h3>
            <p><strong>État :</strong> <?= htmlspecialchars($m->getEtat()) ?></p>
            <p><strong>Durée max :</strong> <?= $m->getDureeMax() ?> jours</p>
            <p>
                <?php if ($m->isDisponible()): ?>
                    <span class="badge badge-green">Disponible</span>
                <?php else: ?>
                    <span class="badge badge-red">Indisponible</span>
                <?php endif; ?>
            </p>
            <a href="<?= $base ?>/index.php?page=detail&id=<?= $m->getId() ?>"
               class="btn btn-primary btn-sm" style="margin-top:10px;">Voir le détail</a>
        </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
